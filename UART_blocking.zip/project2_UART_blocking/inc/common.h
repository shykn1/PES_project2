/**
*	@file 			common.h
*	@brief 		Some common functions for this project
*	
*
*	@author 		
*	@date 			March 30 2019 
*	@version  	1.0
*/
#ifndef  __COMMON__
#define __COMMON__
#include "MKL25Z4.h"
#include "stdbool.h"

#endif
